package com.example.aplicaciongrupo;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class InicioSesion extends AppCompatActivity {

    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio_sesion);
       //databaseReference = FirebaseDatabase.getInstance().getReference("Alumnos");


        //----------------DEFINICIÓN DE LAS VARIABLES PARA LOS CAMPOS----------------------------------------------------

        EditText editText_id = (EditText) findViewById(R.id.editText_idAlumno);
        EditText editText_nombre = (EditText) findViewById(R.id.editText_nombreAlumno);
        EditText editText_contrasena = (EditText) findViewById(R.id.editText_contrasenaAlumno);

        //----------------DEFINICIÓN DE AUTOCOMPLETE----------------------------------------------------------------------------------------------
        AutoCompleteTextView autocomplete_clases = (AutoCompleteTextView) findViewById(R.id.AutocompleteText);
        String[] ciclos = {"DAM", "Mediacion Comunicativa", "Protesis Dentales", "Integracion Social", "Educacion Infantil"};
        ArrayAdapter<String> adaptador = new ArrayAdapter<>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, ciclos);
        autocomplete_clases.setAdapter(adaptador);

        //-----------------DEFINICIÓN DEL BOTÓN CONTINUAR----------------------------------------
        Button botonContinuar = (Button) findViewById(R.id.botonMenuPrincipal);
        botonContinuar.setOnClickListener(new View.OnClickListener() {

            String nombreAlumno = editText_nombre.getText().toString();
            String idAlumno = editText_id.getText().toString();
            String contrasenaAlumno = editText_contrasena.getText().toString();
            String ciclo = autocomplete_clases.getText().toString();

            @Override
            public void onClick(View v) {

                String idAlumno = editText_id.getText().toString();
                String contrasenaAlumno = editText_contrasena.getText().toString();
                String nombreAlumno = editText_nombre.getText().toString();
                String ciclo = autocomplete_clases.getText().toString();

                comprobarExistenciaAlumno(idAlumno, contrasenaAlumno, nombreAlumno);
            }
        });
    }

    private void comprobarExistenciaAlumno(String idAlumno, String contrasenaAlumno, String nombreAlumno) {
        DatabaseReference alumnosRef = FirebaseDatabase.getInstance().getReference("Alumnos");

        alumnosRef.child(idAlumno).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // El alumno existe en la base de datos
                    Alumno alumno = dataSnapshot.getValue(Alumno.class);
                    if (alumno != null && alumno.getNombre() != null && alumno.getContrasena() != null) {
                        // Comprobar el nombre de usuario y la contraseña
                        Log.d("Autenticación", "Nombre esperado: " + nombreAlumno + ", Contraseña esperada: " + contrasenaAlumno);
                        Log.d("Autenticación", "Nombre real: " + alumno.getNombre() + ", Contraseña real: " + alumno.getContrasena());

                        if (alumno.getNombre().equals(nombreAlumno) && alumno.getContrasena().equals(contrasenaAlumno)) {
                            // Las credenciales son correctas
                            Intent intent = new Intent(InicioSesion.this, Fragment_todas.class);
                            // Puedes pasar datos adicionales si es necesario
                            intent.putExtra("ID_ALUMNO", idAlumno);
                            startActivity(intent);
                            Toast.makeText(InicioSesion.this, "Autenticación exitosa. Bienvenido, " + nombreAlumno, Toast.LENGTH_SHORT).show();
                            // Aquí puedes realizar acciones adicionales si es necesario
                        } else {
                            // Las credenciales son incorrectas
                            mostrarMensajeError("Credenciales incorrectas");
                        }
                    } else {
                        // Tratar el caso en que no se pudo convertir a Alumno o nombre/contraseña son nulos
                        mostrarMensajeError("Error al obtener datos del alumno");
                    }
                } else {
                    // El alumno no existe en la base de datos
                    mostrarMensajeError("Alumno no encontrado");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Manejar errores de la base de datos
                mostrarMensajeError("Error en la consulta");
            }
        });

    }

    private void mostrarMensajeError(String mensaje) {
        Toast.makeText(InicioSesion.this, mensaje, Toast.LENGTH_SHORT).show();
    }


}
