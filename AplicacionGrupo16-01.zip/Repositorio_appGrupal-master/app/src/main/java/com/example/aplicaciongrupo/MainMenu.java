package com.example.aplicaciongrupo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;


import com.google.android.material.navigation.NavigationView;

public class MainMenu extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        Toolbar toolbar = (Toolbar) findViewById(R.id.tool_bar);
        setSupportActionBar(toolbar);

        drawerLayout = findViewById(R.id.drawerLayout);

        NavigationView navigationView = findViewById(R.id.nav_view);
        // Establece un escuchador para manejar eventos de selección de elementos en el NavigationView
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.opennav, R.string.closenav);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Si no hay un estado guardado, realiza una transacción de fragmento inicial y establece el elemento seleccionado en la barra de navegación
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainer, new Fragment_todas()).commit();
            navigationView.setCheckedItem(R.id.nav_todas_tareas);
        }
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.nav_crear) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainer, new Fragment_crear()).commit();
        } else if (itemId == R.id.nav_estudio) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainer, new Fragment_estudio()).commit();
        } else if (itemId == R.id.nav_grupal) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainer, new Fragment_grupal()).commit();
        } else if (itemId == R.id.nav_personal) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainer, new Fragment_personal()).commit();
        } else if(itemId == R.id.nav_todas_tareas){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainer, new Fragment_todas()).commit();
        }
        else if (itemId == R.id.nav_exit) {
            // Muestra un mensaje de tostada indicando "Exit!"
            Toast.makeText(this, "Exit!", Toast.LENGTH_SHORT).show();
            Intent volverInicio = new Intent(MainMenu.this, InicioSesion.class);
            startActivity(volverInicio);
        }
        return false;
    }


    @Override
    public void onBackPressed() {
        // Si el cajón de navegación está abierto, ciérralo; de lo contrario, realiza el comportamiento predeterminado de la tecla de retroceso
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}