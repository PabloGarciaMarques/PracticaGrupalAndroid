package com.example.aplicaciongrupo;
import java.util.List;

public class Alumno {
    private String Nombre;
    private int idAlumno;
    private String contrasena;
    private String Ciclo;

    public Alumno() {
        // Constructor vacío requerido para Firebase
    }

    public Alumno(String Nombre, int idAlumno, String contrasena, String Ciclo) {
        this.Nombre = Nombre;
        this.idAlumno = idAlumno;
        this.contrasena = contrasena;
        this.Ciclo = Ciclo;
    }

    // Getters y setters

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        this.Nombre = nombre;
    }

    public int getIdAlumno() {
        return idAlumno;
    }

    public void setIdAlumno(int idAlumno) {
        this.idAlumno = idAlumno;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getCiclo() {
        return Ciclo;
    }

    public void setCiclo(String ciclo) {
        this.Ciclo = ciclo;
    }

    public void setTareas(List<Tarea> tareasDelAlumno) {
    }
}

