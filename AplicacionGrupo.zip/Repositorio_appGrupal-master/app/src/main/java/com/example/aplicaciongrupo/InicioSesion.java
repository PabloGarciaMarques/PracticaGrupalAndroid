package com.example.aplicaciongrupo;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class InicioSesion extends AppCompatActivity {

    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio_sesion);
       databaseReference = FirebaseDatabase.getInstance().getReference("Alumnos");


        //----------------DEFINICIÓN DE LAS VARIABLES PARA LOS CAMPOS----------------------------------------------------

        EditText editText_id = (EditText) findViewById(R.id.editText_idAlumno);
        EditText editText_nombre = (EditText) findViewById(R.id.editText_nombreAlumno);
        EditText editText_contrasena = (EditText) findViewById(R.id.editText_contrasenaAlumno);

        //----------------DEFINICIÓN DE AUTOCOMPLETE----------------------------------------------------------------------------------------------
        AutoCompleteTextView autocomplete_clases = (AutoCompleteTextView) findViewById(R.id.AutocompleteText);
        String[] ciclos = {"DAM", "Mediacion Comunicativa", "Protesis Dentales", "Integracion Social", "Educacion Infantil"};
        ArrayAdapter<String> adaptador = new ArrayAdapter<>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, ciclos);
        autocomplete_clases.setAdapter(adaptador);

        //-----------------DEFINICIÓN DEL BOTÓN CONTINUAR----------------------------------------
        Button botonContinuar = findViewById(R.id.botonMenuPrincipal);
        botonContinuar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String idAlumno = editText_id.getText().toString();
                String contrasenaAlumno = editText_contrasena.getText().toString();
                String nombreAlumno = editText_nombre.getText().toString();
                String ciclo = autocomplete_clases.getText().toString();

                comprobarExistenciaAlumno(idAlumno, contrasenaAlumno, nombreAlumno);
            }
        });
    }

    private void comprobarExistenciaAlumno(String idAlumno, String contrasenaAlumno, String nombreAlumno) {
        databaseReference.child(idAlumno).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    obtenerYMostrarTareas(idAlumno); // Llamamos a la función que busca y muestra las tareas
                    // Resto del código...
                } else {
                    // Resto del código...
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Manejar errores de la base de datos
                mostrarMensajeError("Error en la consulta");
            }
        });
    }

    private void obtenerYMostrarTareas(String idAlumno) {
        databaseReference.orderByChild("idAlumno").equalTo(idAlumno).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                ArrayList<String> listaTareas = new ArrayList<>(); // ArrayList para almacenar las tareas

                if (dataSnapshot.exists()) {
                    for (DataSnapshot tareaSnapshot : dataSnapshot.getChildren()) {
                        Tarea tarea = tareaSnapshot.getValue(Tarea.class);
                        if (tarea != null) {
                            String infoTarea = "ID Tarea: " + tarea.getIdTarea() + "\nResumen: " + tarea.getResumen() +
                                    "\nTipo: " + tarea.getTipo();
                            listaTareas.add(infoTarea);
                        }
                    }
                    // Aquí puedes pasar el ArrayList a la siguiente actividad
                    Intent intent = new Intent(InicioSesion.this, PantallaPrincipal.class);
                    intent.putExtra("ID_ALUMNO", idAlumno);
                    intent.putStringArrayListExtra("LISTA_TAREAS", listaTareas);
                    startActivity(intent);
                } else {
                    // No se encontraron tareas para el alumno
                    mostrarMensajeError("No hay tareas para este alumno.");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Manejar errores de la base de datos
                mostrarMensajeError("Error al obtener tareas.");
            }
        });
    }

    private void mostrarMensajeError(String mensaje) {
        Toast.makeText(InicioSesion.this, mensaje, Toast.LENGTH_SHORT).show();
    }

}
