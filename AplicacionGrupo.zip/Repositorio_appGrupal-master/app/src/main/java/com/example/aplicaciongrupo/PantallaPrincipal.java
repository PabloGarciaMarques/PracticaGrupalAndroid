package com.example.aplicaciongrupo;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class PantallaPrincipal extends AppCompatActivity {

    private DatabaseReference tareasRef;
    private ListView listViewTareas;
    private ArrayAdapter <String> adapter;
    private List<String> listaTareas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_principal);

        // Obtener la referencia a la base de datos
        tareasRef = FirebaseDatabase.getInstance().getReference("tareas");

        // Inicializar vistas
        listViewTareas = findViewById(R.id.listViewTareas);
        listaTareas = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaTareas);
        listViewTareas.setAdapter(adapter);
        String idAlumno = getIntent().getStringExtra("ID_ALUMNO");
        Log.d("ID_ALUMNO", "ID_ALUMNO recibido: " + idAlumno);

        // Obtener y mostrar las tareas del alumno
        obtenerYMostrarTareas(idAlumno);
    }

    private void obtenerYMostrarTareas(String idAlumno) {
        Log.d("ID_ALUMNO", "ID_ALUMNO a buscar: " + idAlumno);

        tareasRef.orderByChild("idAlumno").equalTo(idAlumno).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                listaTareas.clear(); // Limpiar la lista antes de agregar nuevas tareas

                if (dataSnapshot.exists()) {
                    for (DataSnapshot tareaSnapshot : dataSnapshot.getChildren()) {
                        Tarea tarea = tareaSnapshot.getValue(Tarea.class);
                        if (tarea != null) {
                            String infoTarea = "ID Tarea: " + tarea.getIdTarea() + "\nResumen: " + tarea.getResumen() +
                                    "\nTipo: " + tarea.getTipo();
                            listaTareas.add(infoTarea);
                        }
                    }
                    adapter.notifyDataSetChanged(); // Notificar al adaptador que los datos han cambiado
                    Log.d("TAREAS", "Número de tareas encontradas: " + listaTareas.size());
                } else {
                    // No se encontraron tareas para el alumno
                    listaTareas.add("No hay tareas para este alumno.");
                    adapter.notifyDataSetChanged();
                    Log.d("TAREAS", "No hay tareas para este alumno.");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Manejar errores de la base de datos
                listaTareas.add("Error al obtener tareas.");
                adapter.notifyDataSetChanged();
                Log.e("TAREAS", "Error al obtener tareas: " + error.getMessage());
            }
        });
    }

}
